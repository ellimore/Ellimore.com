# Discord bot setup (not yet connected)

This folder documents the bot integration planned for Ellimor. The starter package does not include a live bot process or real customer verification.

1. Create a Discord application at https://discord.com/developers/applications.
2. Add a bot user and configure only the intents/permissions it actually needs.
3. Invite it using Discord's OAuth2 URL Generator. Start with least-privilege permissions.
4. Store `DISCORD_BOT_TOKEN` only in the backend environment, never in `public/` or browser JavaScript.
5. Implement account linking with Discord OAuth2, including `state` validation.
6. Verify subscription state server-side before assigning customer roles.
7. Handle Discord API errors, rate limits, role hierarchy, and guild membership.
8. Add a way to unlink accounts and revoke access.

Potential initial slash commands:
- `/link` — show a short-lived account-link flow
- `/plan` — show the verified plan from the backend
- `/project` — show projects the linked user is allowed to access
- `/sync-role` — synchronize a configured role after server-side authorization

Do not use a Discord bot token shared in chat or a client-side environment variable.
