// Minimal backend scaffold. This intentionally does not execute uploaded Lua.
require("dotenv").config();
const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "200kb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "ellimor-api", mode: "starter-scaffold" });
});

// TODO production: authentication middleware, per-user authorization,
// server-side file upload/storage, database, audit logs, and plan checks.
// Do not expose secrets or trust plan data supplied by a browser.
app.get("/api/status", (_req, res) => {
  res.json({
    authenticated: false,
    discordConfigured: Boolean(process.env.DISCORD_BOT_TOKEN),
    billingConfigured: false,
    message: "Starter scaffold only; no accounts, payments, or script execution."
  });
});

app.listen(PORT, () => {
  console.log(`Ellimor starter running at http://localhost:${PORT}`);
});
