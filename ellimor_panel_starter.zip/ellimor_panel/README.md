# Ellimor Panel — Free Starter

A responsive black-and-purple dashboard prototype for managing authorized Roblox Studio and standalone Lua projects.

## What works now
- Dashboard navigation and mobile sidebar
- Create up to three demo projects
- Import `.lua`, `.luau`, `.txt`, or `.json` files locally (200 KB demo limit)
- Preview imported text locally; the demo does **not** execute uploaded code
- Create and remove release records
- Local workspace settings and JSON export
- Discord integration setup guide and plan UI preview
- Browser `localStorage` persistence

## Important limitations
This is a static front-end prototype, not a production service. It does not include user authentication, real server-side file uploads, a live Discord bot, payments, subscription verification, secure script delivery, or any executor integration. Browser local storage is not secure storage. Never put bot tokens, API keys, passwords, or payment secrets in front-end files.

## Free local preview
Open `public/index.html` in a modern browser, or use VS Code's Live Server extension.

## Free static hosting
Upload the contents of `public/` to a GitHub repository and enable GitHub Pages. A static host can publish the UI, but it cannot run the backend or Discord bot.

## Suggested production architecture
- Frontend: this `public/` folder, hosted on GitHub Pages
- API: Node.js/Express or another server on a free-tier host
- Database: a free-tier Postgres service or SQLite for a tiny single-instance prototype
- File storage: server-side object storage with per-user access controls
- Discord: bot process using Discord's official API; keep its token in environment variables
- Billing: add a provider later; keep plan checks on the server

## Security checklist before launch
1. Add authentication and server-side authorization to every project/file route.
2. Validate file type and size server-side; store uploads outside the public web root.
3. Treat uploaded Lua as untrusted text. Do not execute arbitrary customer uploads on the server.
4. Use Discord OAuth2 state validation and verify guild/role permissions server-side.
5. Store secrets only in server environment variables.
6. Use real payment-provider webhooks for plan status; never trust a browser-supplied plan name.
7. Add rate limits, audit logs, backups, and a privacy policy/terms before accepting customers.

The project is intended for scripts and projects you own or are authorized to distribute.
