Bot source: `index.js`. See the root README for Railway deployment instructions.
